(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_901137b7._.js",
  "static/chunks/[root-of-the-server]__adc7c97a._.css"
],
    source: "dynamic"
});
